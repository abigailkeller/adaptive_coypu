#include "MDP.h"
#include <stdio.h>
#include <time.h>
#include <sstream>
#include <iostream>


// reads in a policy from filename
// queries the policy with state
// returns the action or -1 if fail
void mdpquery(char *filename)
{
  int optact(-1);
  
  DdNode *act, *val;

  DdNode **UPList= (DdNode **)malloc(2*(sizeof(DdNode *)));

  
  MDP *mdp = new MDP;

  //load from this file into dd: act and val
  clock_t start = clock();
  int numread = mdp->readDualOptimal(gbm,filename,&UPList);
  fprintf(stderr, "time for loading file:  %f\n", ((double)clock() - start) / CLOCKS_PER_SEC);
 
  if (numread == 0) {
    fprintf(stderr,"error reading dual policy from %s\n",filename);
    free(UPList);
    exit(1);
  } else {
    act = UPList[0];
    Cudd_Ref(act);

    val = UPList[1];
    Cudd_Ref(val);
    free(UPList);
  }

  string param = "";

  onum * orig_vars = mdp->getOrigVars();
  int nvars = mdp->getNumOrigvars();  
  int *state = new int[nvars];

  // waits for queries from stdin
  // results are sent to stdout
  while(getline(cin, param)) {

    if (param == "stop")
      break;

    if (param == "start")
      continue;

    istringstream iss(param);

    for (int i = 0; i < nvars; i++) {
      iss>>state[i];
    }

    fprintf(stderr,"numvars in mdp is %d\n",nvars);
    for (int i=0; i<nvars; i++)  { 
      fprintf(stderr,"%s=%s\n",orig_vars[i].name,orig_vars[i].valname[state[i]]);
    }

    start = clock();
    optact = mdp->consultOptimalPolicy(act,val,state);
    fprintf(stderr,"action was %d which is %s\n",optact,mdp->getActionName(optact));
    fprintf(stderr, "time for querying file:  %f\n", ((double)clock() - start) / CLOCKS_PER_SEC);
  }

  delete [] state;

  // could call server 
  //return optact;
}


// test binary for mdpquery function
int main(int argc, char *argv[])
{
  if (argc < 2) {
    fprintf(stderr,"usage: pquery <dualADD filename> <state1val> <state2val> ...\n");
    exit(1);
  }
  char * policyFile = *++argv;
  
  mdpquery(policyFile);

  return 1;
}
