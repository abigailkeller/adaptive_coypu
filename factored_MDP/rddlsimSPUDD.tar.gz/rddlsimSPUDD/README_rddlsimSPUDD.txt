ICAPS version of SPUDD

SPUDD source code is included this package under folder SPUDD.

The following modifications were made to version 3.6.2:

Put in a timer parameter (-d) for SPUDD to stop further iterations and generate a policy if the most recent iteration is completed past the max time.

Placed mdpquery (mdpqueryLoop) in a loop to listen for query requests.  

Removed the line //if(Cudd_ReadMemoryInUse(gbm)>MAXMEMHARD)) from MDP.cc and GSpudd/MDP.cpp because it was not working properly during tests for the competition.


***********************************************************************************************

Usage:  

For running the server and client on a single instance trial see the rddlsim instructions in INSTALL.txt.

To run the client on multiple instances:

./runAll <location of RDDL files> <host-name> <client-name> <port number> <random seed> <instance list file> [max time]

For example, to reproduce the same results from the ICAPS competition:

./runAll files/final_comp/rddl localhost uwaterloo 2323 1234 icaps_comp_run_list

Please contact George Zhu (g6zhu@uwaterloo.ca), Marek Grzes (mgrzes@cs.uwaterloo.ca), and Jesse Hoey (jhoey@cs.uwaterloo.ca) with any questions or comments.
