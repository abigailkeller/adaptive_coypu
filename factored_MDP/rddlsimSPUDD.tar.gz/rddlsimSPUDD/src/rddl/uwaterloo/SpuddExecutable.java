/*
 * Wrapper class for the SPUDD binary, generates the SPUDD policy.
 * 
 * George Zhu, University of Waterloo, g6zhu@uwaterloo.ca
 * 
 */

package rddl.uwaterloo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class SpuddExecutable {

	public static final boolean SHOW_OUTPUT = false;
	public static final String SPUDD_EXECUTABLE_LOC = "";
	public static long executionTime;
	
	// calls the Spudd binary
	public boolean executeSpudd(String filename) {

		String cmd;

		if (rddl.competition.Client.maxTime > 0) {

			cmd = "./" + SPUDD_EXECUTABLE_LOC + "Spudd " + filename + " -r sift -d "
					+ rddl.competition.Client.maxTime;
		}

		else {
			cmd = "./" + SPUDD_EXECUTABLE_LOC + "Spudd " + filename + " -r sift";
		}

		try {
			long startTime = System.currentTimeMillis();

			if (SHOW_OUTPUT)
				System.out
						.println("\n*****Starting execution of Spudd with command:   "
								+ cmd);

			Process p = Runtime.getRuntime().exec(cmd);
			
			BufferedReader stdErrReader = new BufferedReader(new InputStreamReader(p.getErrorStream()));
			
			String line = "";
			
			while ((line = stdErrReader.readLine()) != null) {
				System.out.println(line);
			}

			p.waitFor();

			assert (p.exitValue() == 0);

			long endTime = System.currentTimeMillis();

			executionTime = endTime - startTime;

			return true;
		} catch (IOException e) {
			e.printStackTrace();
			System.err.println(e.toString());
			return false;
		} catch (InterruptedException e) {
			System.err.println(e.toString());
			return false;

		} finally {
			
			if (SHOW_OUTPUT) {
				System.out.println("*****Spudd completed execution.*****");
			}
		}
	}
}
