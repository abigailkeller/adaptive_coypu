/*
 * 
 * Wrapper class to call mdpqueryLoop binary to query the SPUDD policy.
 * 
 * George Zhu, University of Waterloo, g6zhu@uwaterloo.ca
 * 
 */

package rddl.uwaterloo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class MdpqueryExecutable {
	public static final boolean SHOW_OUTPUT = true;
	public static final String MDPQUERY_EXECUTABLE_LOC = "";
	public static final String SPUDD_ADD_LOC = "";
	public String action;
	public static boolean finished = false;
	
	public long totalQueryTime;

	ProcessBuilder pb;
	Process p;

	public MdpqueryExecutable() throws IOException {

		action = "";

		totalQueryTime = System.currentTimeMillis();

		pb = new ProcessBuilder("./mdpqueryLoop", "SPUDD-OPTDual.ADD");
		p = pb.start();

		final Scanner in = new Scanner(p.getErrorStream());
		if (in.hasNextLine() && SHOW_OUTPUT) {
			System.out.println(in.nextLine());
		}

		new Thread() {
			public void run() {
				String line;
				while (in.hasNextLine() && !finished) {
					line = in.nextLine();
					
					if (SHOW_OUTPUT) {
						System.out.println(line);
					}

					if (line.contains("which")) {
						action = line.substring(line.lastIndexOf(' ') + 1);
					}
				}
				
				in.close();
			}
		}.start();
	}

	public void runQuery(String params) {

		PrintWriter out = new PrintWriter(p.getOutputStream());
		out.println(params);
		
		if (SHOW_OUTPUT) {
			
			System.out.println("\n***Running mdpquery with state values " + params + "***");
		}

		if (params.equals("stop")) {
			totalQueryTime = System.currentTimeMillis() - totalQueryTime;
			finished = true;
		}
		out.flush();
	}
}
