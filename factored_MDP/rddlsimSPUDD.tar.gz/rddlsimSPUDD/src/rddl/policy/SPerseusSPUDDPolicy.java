/**
 * RDDL: This policy is for use with the Symbolic Perseus and SPUDD
 *       translations.  The planner displays state (MDP) or observations
 *       (POMDP) as true fluents as well as possible actions and
 *       then randomly takes an action.  State-action constraints are
 *       not checked.
 * 
 * @author Scott Sanner (ssanner [at] gmail.com)
 * @version 12/18/10
 *
 **/

/*
 * Modified the getActions method to set the true variables to a format
 * recognized by SPUDD.  
 * 
 * George Zhu, University of Waterloo, g6zhu@uwaterloo.ca
 * 
 */

package rddl.policy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TreeSet;

import rddl.ActionGenerator;
import rddl.EvalException;
import rddl.State;
import rddl.RDDL.LCONST;
import rddl.RDDL.PVAR_INST_DEF;
import rddl.RDDL.PVAR_NAME;
import rddl.translate.RDDL2Format;
import rddl.uwaterloo.MdpqueryExecutable;
import rddl.uwaterloo.SpuddExecutable;

///////////////////////////////////////////////////////////////////////////
//                             Helper Functions
///////////////////////////////////////////////////////////////////////////

public class SPerseusSPUDDPolicy extends Policy {

	public final static boolean SHOW_STATE = true;
	public final static boolean SHOW_ACTIONS = true;
	public final static boolean SHOW_ACTION_TAKEN = true;
	public final static String PROBLEM_FILE_DIRECTORY = "files/final_comp/spudd_sperseus/";

	// public final static boolean ALLOW_NOOP = false;

	// Just use the default random seed
	public Random _rand = new Random();

	String instanceName;
	SpuddExecutable spuddExecutable;
	MdpqueryExecutable mdpqueryExecutable;
	HashMap<String, Integer> varKeys;

	public SPerseusSPUDDPolicy() {
	}

	public SPerseusSPUDDPolicy(String instance_name) throws IOException {
		super(instance_name);
		instanceName = instance_name;
		varKeys = new HashMap<String, Integer>();
		setVarNameKeys(findProblemFile(instance_name));
		spuddExecutable = new SpuddExecutable();
		spuddExecutable.executeSpudd(findProblemFile(instance_name));
		mdpqueryExecutable = new MdpqueryExecutable();
	}

	// /////////////////////////////////////////////////////////////////////////
	// Main Action Selection Method
	//
	// If you're using Java and the SPUDD / Symbolic Perseus Format, this
	// method is the only client method you need to understand to implement
	// your own custom policy.
	// /////////////////////////////////////////////////////////////////////////

	public ArrayList<PVAR_INST_DEF> getActions(State s) throws EvalException {

		if (s == null) {
			// This should only occur on the **first step** of a POMDP trial
			// when no observations have been generated, for now, we just
			// return a 'noop'
			System.out.println("NO STATE/OBS: taking noop\n\n");
			return new ArrayList<PVAR_INST_DEF>();
		}

		// If the domain is partially observed, we only see observations,
		// otherwise if it is fully observed, we see the state
		String fluent_type = s._alObservNames.size() > 0 ? "observ" : "states";

		// System.out.println("FULL STATE:\n\n" + getStateDescription(s));

		// temporary storage mdpquery parameter string
		String temp[] = new String[varKeys.size()];

		for (int i = 0; i < temp.length; i++) {
			temp[i] = "1 ";
		}

		// Get a set of all true observation or state variables
		TreeSet<String> true_vars = getTrueFluents(s, fluent_type);
		
		for (String prop_var : true_vars) {

			// set true variable to a value of 0
			if (varKeys.containsKey(prop_var)) {
				temp[varKeys.get(prop_var)] = "0 ";
			}
			
			if (SHOW_STATE) {
				System.out
						.println("\n==============================================");
				System.out.println("\nTrue state/observation variables:");
			System.out.println(" - " + prop_var);
			}
		}
		

		// build mdpquery parameter string
		StringBuilder mdpQueryPara = new StringBuilder();

		for (int i = 0; i < temp.length; i++) {
			mdpQueryPara.append(temp[i]);
			temp[i] = "1 ";
		}

		// Get a map of { legal action names -> RDDL action definition }
		Map<String, ArrayList<PVAR_INST_DEF>> action_map = ActionGenerator
				.getLegalBoolActionMap(s);

		if (SHOW_STATE) {
			System.out.println("\nLegal action names:");
			for (String action_name : action_map.keySet())
				System.out.println(" - " + action_name);
		}

		String action_taken = "";

		mdpqueryExecutable.runQuery(mdpQueryPara.toString());

		action_taken = mdpqueryExecutable.action;

		while (action_taken == null || action_taken == "") {
			try {
				Thread.currentThread().sleep(500);
				action_taken = mdpqueryExecutable.action;

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		mdpQueryPara.delete(0, mdpQueryPara.length() - 1);

		// Return a random action selection
		// ArrayList<String> actions = new
		// ArrayList<String>(action_map.keySet());
		// String action_taken = actions.get(_rand.nextInt(actions.size()));
		// if (SHOW_ACTION_TAKEN)
		// System.out.println("\n--> Action taken: " + action_taken);

		return action_map.get(action_taken);
	}

	// /////////////////////////////////////////////////////////////////////////
	// Helper Methods
	//
	// You likely won't need to understand the code below, only the above code.
	// /////////////////////////////////////////////////////////////////////////

	public TreeSet<String> getTrueFluents(State s, String fluent_type) {

		// Go through all variable types (state, interm, observ, action,
		// nonfluent)
		TreeSet<String> true_fluents = new TreeSet<String>();
		for (PVAR_NAME p : (ArrayList<PVAR_NAME>) s._hmTypeMap.get(fluent_type)) {

			try {
				// Go through all term groundings for variable p
				ArrayList<ArrayList<LCONST>> gfluents = s.generateAtoms(p);
				for (ArrayList<LCONST> gfluent : gfluents) {
					if ((Boolean) s.getPVariableAssign(p, gfluent)) {
						true_fluents.add(RDDL2Format
								.CleanFluentName(p._sPVarName + gfluent));
					}
				}
			} catch (Exception ex) {
				System.err
						.println("SPerseusSPUDDPolicy: could not retrieve assignment for "
								+ p + "\n");
			}
		}

		return true_fluents;
	}

	public String getStateDescription(State s) {
		StringBuilder sb = new StringBuilder();

		// Go through all variable types (state, interm, observ, action,
		// nonfluent)
		for (Map.Entry<String, ArrayList<PVAR_NAME>> e : s._hmTypeMap
				.entrySet()) {

			if (e.getKey().equals("nonfluent"))
				continue;

			// Go through all variable names p for a variable type
			for (PVAR_NAME p : e.getValue()) {
				sb.append(p + "\n");
				try {
					// Go through all term groundings for variable p
					ArrayList<ArrayList<LCONST>> gfluents = s.generateAtoms(p);
					for (ArrayList<LCONST> gfluent : gfluents)
						sb.append("- " + e.getKey() + ": " + p
								+ (gfluent.size() > 0 ? gfluent : "") + " := "
								+ s.getPVariableAssign(p, gfluent) + "\n");

				} catch (EvalException ex) {
					sb.append("- could not retrieve assignment " + s + " for "
							+ p + "\n");
				}
			}
		}

		return sb.toString();
	}

	public String findProblemFile(String instanceName) {

		File directory = new File(PROBLEM_FILE_DIRECTORY);
		File[] files = directory.listFiles();

		for (File file : files) {
			String filename = file.getName();
			if (filename.equals(instanceName + ".spudd")) {
				return PROBLEM_FILE_DIRECTORY + filename;
			}
		}

		System.err.println("Error:  cannot find .spudd file for instance "
				+ instanceName);

		return null;
	}

	// map state variable names to variable index, required by mdpquery
	// parameters
	public void setVarNameKeys(String filename) throws IOException {

		int count = 0;

		BufferedReader br = new BufferedReader(new FileReader(filename));
		String line = "";

		while ((line = br.readLine()) != null) {

			if (line.startsWith("(variables")) {

				while (!(line = br.readLine()).startsWith(")")) {

					String[] temp = line.split("[(\\s+]");
					varKeys.put(temp[2], count++);
				}

				break;
			}
		}
	}

	public void sessionEnd(double total_reward) {
		System.out
				.println("\n*********************************************************");
		System.out.println(">>> SESSION END, total reward = " + total_reward);
		System.out
				.println("*********************************************************");

		mdpqueryExecutable.runQuery("stop");

		// write log
		// try {
		// FileWriter fw = new FileWriter("trialResults/results.txt", true);
		// BufferedWriter bw = new BufferedWriter(fw);
		// bw.write(instanceName + "\t" + total_reward + "\t" + total_reward
		// / 30 + "\t"
		// + Math.round(spuddExecutable.executionTime / 1000) + "\t"
		// + mdpqueryExecutable.totalQueryTime + "\n");
		// bw.close();
		// } catch (IOException e) {
		// // TODO Auto-generated catch block
		// e.printStackTrace();
		// }

	}
}
